-- AlterTable
ALTER TABLE `Recipe` MODIFY `notes` JSON NULL;
